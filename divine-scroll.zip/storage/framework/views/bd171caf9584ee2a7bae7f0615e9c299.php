<?php
    $attr = $passage->attribution;
    $who = $attr?->person;
?>

<?php if($who): ?>
<article class="post">
    <a class="avatar kind-<?php echo e($who->kind); ?>" href="<?php echo e(route('person', $who)); ?>" aria-hidden="true" tabindex="-1"><?php echo e(mb_substr($who->name, 0, 1)); ?></a>

    <div class="body">
        <div class="head">
            <a class="name" href="<?php echo e(route('person', $who)); ?>"><?php echo e($who->name); ?></a>
            <span class="handle"><?php echo e($who->handle); ?></span>
            <span class="handle">·</span>
            <a class="ref" href="<?php echo e(route('passage', $passage)); ?>"><?php echo e($passage->reference); ?></a>
        </div>

        <?php if($passage->heading): ?>
            <p class="heading-text"><?php echo e($passage->heading); ?></p>
        <?php endif; ?>

        <p class="text"><?php echo e($passage->body); ?></p>

        <?php
            $outgoing = $passage->outgoing
                ->filter(fn ($l) => $l->to && $l->to->status === 'approved' && $l->to->attribution)
                ->sortBy(fn ($l) => $l->type === 'quote' ? 0 : 1)
                ->take(2);
            $incoming = $passage->incoming
                ->filter(fn ($l) => $l->from && $l->from->status === 'approved' && $l->from->attribution)
                ->sortBy(fn ($l) => $l->type === 'quote' ? 0 : 1)
                ->values();
        ?>

        <?php $__currentLoopData = $outgoing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="quote" href="<?php echo e(route('passage', $link->to)); ?>">
                <div class="muted" style="font-size: 12px; margin-bottom: 2px;"><?php echo e($link->type === 'quote' ? 'Quoting' : 'Referring to'); ?></div>
                <div class="head">
                    <span class="name"><?php echo e($link->to->attribution->person->name); ?></span>
                    <span class="handle"><?php echo e($link->to->attribution->person->handle); ?></span>
                    <span class="handle">· <?php echo e($link->to->reference); ?></span>
                </div>
                <?php if($link->to->heading): ?>
                    <p class="heading-text"><?php echo e($link->to->heading); ?></p>
                <?php endif; ?>
                <p class="text"><?php echo e($link->to->body); ?></p>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if(!empty($passage->themes)): ?>
            <div class="tag-list">
                <?php $__currentLoopData = $passage->themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="tag">#<?php echo e($theme); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <div class="actions">
            <details class="basis basis-<?php echo e($attr->basis); ?>">
                <summary><?php echo e($attr->basisLabel()); ?></summary>
                <?php if($attr->note): ?>
                    <p><?php echo e($attr->note); ?></p>
                <?php endif; ?>
            </details>

            <button type="button" class="share" data-share
                data-url="<?php echo e(route('passage', $passage)); ?>"
                data-title="<?php echo e($who->name); ?> · <?php echo e($passage->reference); ?>"
                data-text="“<?php echo e(\Illuminate\Support\Str::limit($passage->body, 200)); ?>” — <?php echo e($who->name); ?>, <?php echo e($passage->reference); ?>">
                <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 12v7a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-7"/><path d="M16 6l-4-4-4 4"/><path d="M12 2v13"/></svg>
                <span class="share-label">Share</span>
            </button>
        </div>

        <?php $__currentLoopData = $incoming->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="echo">
                <?php echo e($link->type === 'quote' ? 'Quoted by' : 'Echoed by'); ?>

                <a href="<?php echo e(route('passage', $link->from)); ?>"><?php echo e($link->from->attribution->person->name); ?></a>
                in <?php echo e($link->from->reference); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if($incoming->count() > 3): ?>
            <div class="echo">and <?php echo e($incoming->count() - 3); ?> more</div>
        <?php endif; ?>
    </div>
</article>
<?php endif; ?>
<?php /**PATH /Users/macintoshssd/Vortex/Webapps/divine-scroll/resources/views/partials/post.blade.php ENDPATH**/ ?>