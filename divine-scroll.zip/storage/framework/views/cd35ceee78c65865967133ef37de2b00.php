<?php $__env->startSection('title', 'Today'); ?>
<?php $__env->startSection('subtitle', 'Public feed'); ?>

<?php $__env->startSection('content'); ?>
    
    <section class="hero">
        <p class="hero-eyebrow">Voices of Scripture</p>
        <h1 class="hero-title">
            The Bible, quoted<br class="hero-br"> in its own voices.
        </h1>
        <p class="hero-sub">
            Every passage is traced to the person behind it — stated in the text,<br class="hero-br">
            carried by tradition, or spoken where no author is named.
        </p>
    </section>

    
    <?php
        $filterLabels = [
            'all'          => 'All voices',
            'stated'       => 'Stated in text',
            'traditional'  => 'Traditional',
            'speaker'      => 'Speaker, not author',
            'unattributed' => 'Unattributed',
        ];
        $active = $filter ?? 'all';
    ?>
    <div class="filters" id="filters">
        <?php $__currentLoopData = $filterLabels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="filter-btn <?php echo e($active === $key ? 'is-active' : ''); ?>"
               data-filter="<?php echo e($key); ?>"
               href="<?php echo e($key === 'all' ? route('feed') : route('feed', ['basis' => $key])); ?>"><?php echo e($label); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div id="feed" class="feed-container">
        <?php if($posts->isEmpty()): ?>
            <p class="empty">No passages for this filter yet.</p>
        <?php else: ?>
            <?php echo $__env->make('partials.feed-items', ['posts' => $posts], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>
    </div>

    <div class="more-wrap" id="more-wrap" <?php if(! $posts->nextPageUrl()): ?> hidden <?php endif; ?>>
        <a id="more" class="more" href="<?php echo e($posts->nextPageUrl()); ?>">Load More</a>
    </div>

    <p class="muted" id="end-note" style="text-align:center; padding:12px;" <?php if($posts->nextPageUrl() || $posts->isEmpty()): ?> hidden <?php endif; ?>>That’s everything for now.</p>

    <script>
    (function () {
        if (!window.fetch) return;

        var feed = document.getElementById('feed');
        var filters = document.getElementById('filters');
        var wrap = document.getElementById('more-wrap');
        var more = document.getElementById('more');
        var endNote = document.getElementById('end-note');
        var latest = 0;
        var loading = false;

        function getJson(url) {
            return fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json' } })
                .then(function (res) {
                    if (!res.ok) throw new Error('HTTP ' + res.status);
                    return res.json();
                });
        }

        function showNext(next, hasPosts) {
            if (next) { more.href = next; more.textContent = 'Load More'; }
            wrap.hidden = !next;
            endNote.hidden = !!next || !hasPosts;
        }

        // Load more
        more.addEventListener('click', function (e) {
            e.preventDefault();
            if (loading) return;
            loading = true;
            var mine = latest;
            more.textContent = 'Loading…';
            more.setAttribute('aria-busy', 'true');

            getJson(more.href)
                .then(function (data) {
                    if (mine !== latest) return; // a filter was chosen meanwhile
                    feed.insertAdjacentHTML('beforeend', data.html);
                    showNext(data.next, true);
                })
                .catch(function () {
                    more.textContent = 'Couldn’t load. Tap to retry.';
                })
                .then(function () {
                    loading = false;
                    more.removeAttribute('aria-busy');
                });
        });

        // Filters
        filters.addEventListener('click', function (e) {
            var btn = e.target.closest('.filter-btn');
            if (!btn) return;
            e.preventDefault();

            var url = btn.href;
            var mine = ++latest;

            filters.querySelectorAll('.filter-btn').forEach(function (b) { b.classList.remove('is-active'); });
            btn.classList.add('is-active');
            feed.style.opacity = '.5';

            getJson(url)
                .then(function (data) {
                    if (mine !== latest) return;
                    var hasPosts = data.html.trim() !== '';
                    feed.innerHTML = hasPosts ? data.html : '<p class="empty">No passages for this filter yet.</p>';
                    showNext(data.next, hasPosts);
                    history.replaceState(null, '', url);
                })
                .catch(function () {
                    if (mine !== latest) return;
                    feed.innerHTML = '<p class="empty">Couldn’t load this filter. <a href="' + url + '">Try again</a></p>';
                })
                .then(function () {
                    if (mine === latest) feed.style.opacity = '';
                });
        });
    })();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/macintoshssd/Vortex/Webapps/divine-scroll/resources/views/feed.blade.php ENDPATH**/ ?>