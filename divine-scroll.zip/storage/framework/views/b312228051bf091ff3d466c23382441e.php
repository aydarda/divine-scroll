<?php $__env->startSection('title', $shareTitle); ?>
<?php $__env->startSection('subtitle', $passage->reference); ?>

<?php $__env->startSection('meta'); ?>
    <link rel="canonical" href="<?php echo e(route('passage', $passage)); ?>">
    <meta name="description" content="<?php echo e($shareText); ?>">
    <meta property="og:site_name" content="<?php echo e(config('app.name')); ?>">
    <meta property="og:type" content="article">
    <meta property="og:title" content="<?php echo e($shareTitle); ?>">
    <meta property="og:description" content="<?php echo e($shareText); ?>">
    <meta property="og:url" content="<?php echo e(route('passage', $passage)); ?>">
    <meta name="twitter:title" content="<?php echo e($shareTitle); ?>">
    <meta name="twitter:description" content="<?php echo e($shareText); ?>">
    <?php if($cardUrl): ?>
        <meta property="og:image" content="<?php echo e($cardUrl); ?>">
        <meta property="og:image:width" content="1200">
        <meta property="og:image:height" content="630">
        <meta name="twitter:card" content="summary_large_image">
        <meta name="twitter:image" content="<?php echo e($cardUrl); ?>">
    <?php else: ?>
        <meta name="twitter:card" content="summary">
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="back-row">
        <a class="back-link" href="<?php echo e(route('feed')); ?>">← Back to feed</a>
    </div>
    <div class="feed-container">
        <?php echo $__env->make('partials.post', ['passage' => $passage], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/macintoshssd/Vortex/Webapps/divine-scroll/resources/views/passage.blade.php ENDPATH**/ ?>