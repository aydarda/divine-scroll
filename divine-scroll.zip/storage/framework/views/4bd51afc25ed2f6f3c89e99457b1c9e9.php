<?php $__env->startSection('title', $person->name); ?>
<?php $__env->startSection('subtitle', $person->handle); ?>

<?php $__env->startSection('meta'); ?>
    <?php ($about = $person->bio ?: 'Passages posted by ' . $person->name . '.'); ?>
    <link rel="canonical" href="<?php echo e(route('person', $person)); ?>">
    <meta name="description" content="<?php echo e($about); ?>">
    <meta property="og:site_name" content="<?php echo e(config('app.name')); ?>">
    <meta property="og:type" content="profile">
    <meta property="og:title" content="<?php echo e($person->name); ?> (<?php echo e($person->handle); ?>)">
    <meta property="og:description" content="<?php echo e($about); ?>">
    <meta property="og:url" content="<?php echo e(route('person', $person)); ?>">
    <meta name="twitter:card" content="summary">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="feed-container">
        <div class="profile">
            <h1><?php echo e($person->name); ?></h1>
            <div class="muted"><?php echo e($person->handle); ?> · <?php echo e($posts->count()); ?> <?php echo e(\Illuminate\Support\Str::plural('post', $posts->count())); ?></div>
            <?php if($person->bio): ?>
                <p class="bio"><?php echo e($person->bio); ?></p>
            <?php endif; ?>
        </div>

        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $passage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php echo $__env->make('partials.post', ['passage' => $passage], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="empty">No approved posts from this voice yet.</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/macintoshssd/Vortex/Webapps/divine-scroll/resources/views/person.blade.php ENDPATH**/ ?>